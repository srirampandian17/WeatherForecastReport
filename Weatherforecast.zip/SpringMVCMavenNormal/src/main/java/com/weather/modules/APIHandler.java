package com.weather.modules;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.json.JSONArray;
import org.json.JSONObject;
import org.w3c.dom.Document;

import com.weather.objects.Temperature;
import com.weather.objects.Weather;

public class APIHandler {

	public static Weather getWeatherData(String cityName) 
	{
		BufferedReader in = null;
		Weather weather=null;
		try{
			String latLongs[] = getLatLongPositions(cityName);
			String url="https://api.darksky.net/forecast/e089deec6a12461edf606a178d464070/"+latLongs[0]+","+latLongs[1]+"";//No I18n
			System.out.println("  the url is  "+url);
			URL oracle = new URL(url);
			URLConnection testConnection = oracle.openConnection();
			in = new BufferedReader(new InputStreamReader(testConnection.getInputStream()));
			weather=new Weather(cityName);
			JSONObject jObj=new JSONObject(in.readLine());
			JSONObject hourly=jObj.getJSONObject("hourly");//No I18n
			setMaxMinTemperature(weather,hourly);
		}catch(Exception ex){
			ex.printStackTrace();
		}finally
		{
			if(in!=null)
			{
				try{

					in.close();
				}catch(Exception ex){
					ex.printStackTrace();
				}
			}
		}
		return weather;
	}
	
	public static List<Temperature> getHourlyData() throws Exception
	{
		List<Temperature> temperatureList=new ArrayList<Temperature>();
		return temperatureList;
	}
	
	public static void setMaxMinTemperature(Weather weather,JSONObject hourly) throws Exception
	{
		DecimalFormat df2 = new DecimalFormat(".##");
		double maxTemp=Double.MIN_VALUE,minTemp=Double.MAX_VALUE;
		String maxTime="",minTime="";
		JSONArray dataArray=hourly.getJSONArray("data");
		for(int i=0;i<24;i++){
			JSONObject dataObj=(JSONObject) dataArray.get(i);
			double temperature= Double.parseDouble(df2.format((dataObj.getDouble("temperature")-32)*(0.5556)));
			long time=dataObj.getLong("time")*1000;
			if(temperature>maxTemp){
				maxTemp=temperature;
				SimpleDateFormat sdf = new SimpleDateFormat("dd ,hh:mm aaa");
				maxTime=sdf.format(new Date(time))+" ";
			}
			if(temperature<minTemp){
				minTemp=temperature;
				SimpleDateFormat sdf = new SimpleDateFormat("dd ,hh:mm aaa");
				minTime=sdf.format(new Date(time))+" ";
			}
			weather.addData(new Temperature(time, temperature));
		}
		weather.setMaxTemperature(maxTemp+" C");
		weather.setMaxTemptime(maxTime+"");
		weather.setMinTemperature(minTemp+" C");
		weather.setMinTemptime(minTime);
	}
	
	 public static String[] getLatLongPositions(String address) throws Exception
	  {
	    int responseCode = 0;
	    String api = "http://maps.googleapis.com/maps/api/geocode/xml?address=" + URLEncoder.encode(address, "UTF-8") + "&sensor=true";
	    URL url = new URL(api);
	    HttpURLConnection httpConnection = (HttpURLConnection)url.openConnection();
	    httpConnection.connect();
	    responseCode = httpConnection.getResponseCode();
	    if(responseCode == 200)
	    {
	      DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();;
	      Document document = builder.parse(httpConnection.getInputStream());
	      XPathFactory xPathfactory = XPathFactory.newInstance();
	      XPath xpath = xPathfactory.newXPath();
	      XPathExpression expr = xpath.compile("/GeocodeResponse/status");
	      String status = (String)expr.evaluate(document, XPathConstants.STRING);
	      if(status.equals("OK"))
	      {
	         expr = xpath.compile("//geometry/location/lat");
	         String latitude = (String)expr.evaluate(document, XPathConstants.STRING);
	         expr = xpath.compile("//geometry/location/lng");
	         String longitude = (String)expr.evaluate(document, XPathConstants.STRING);
	         return new String[] {latitude, longitude};
	      }
	      else
	      {
	         throw new Exception("Error from the API - response status: "+status);
	      }
	    }
	    return null;
	  }

	private static void disableSslVerification() {
		try
		{
			// Create a trust manager that does not validate certificate chains
			TrustManager[] trustAllCerts = new TrustManager[] {new X509TrustManager() {
				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
					return null;
				}
				public void checkClientTrusted(X509Certificate[] certs, String authType) {
				}
				public void checkServerTrusted(X509Certificate[] certs, String authType) {
				}
			}
			};

			// Install the all-trusting trust manager
			SSLContext sc = SSLContext.getInstance("SSL");
			sc.init(null, trustAllCerts, new java.security.SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

			// Create all-trusting host name verifier
			HostnameVerifier allHostsValid = new HostnameVerifier() {
				public boolean verify(String hostname, SSLSession session) {
					return true;
				}
			};

			// Install the all-trusting host verifier
			HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (KeyManagementException e) {
			e.printStackTrace();
		}
	}

}
