package com.weather.objects;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class Weather 
{
	private String minTemperature;

	private String maxTemperature;
	
	private String maxTemptime;
	
	private String minTemptime;

	private String time;
	
	private String cityName;
	
	Map<Double,String> tempTimeMap=new TreeMap<Double, String>();
	
	private List<String> categories=new ArrayList<String>();
	
	public Weather(String cityName)
	{
		this.cityName=cityName;
	}

	public String getMaxTemperature()
	{
		return maxTemperature;
	}
	
	public List<String> getCategories()
	{
		for(double temp:tempTimeMap.keySet()){
			categories.add("'"+tempTimeMap.get(temp)+"'");
		}
		return categories;
	}
	
	public void setMaxTemperature(String temp)
	{
		this.maxTemperature=temp;
	}
	
	public String getCityName()
	{
		return cityName;
	}
		
	public String getMinTemperature()
	{
		return minTemperature;
	}
	
	public void setMinTemperature(String temp)
	{
		this.minTemperature=temp;
	}
	
	public String getTime()
	{
		return time;
	}
	
	public void setTime()
	{
	}
	public String getMaxTemptime()
	{
		return maxTemptime;
	}
	
	public void setMaxTemptime(String temp)
	{
		this.maxTemptime=temp;
	}
	public String getMinTemptime()
	{
		return minTemptime;
	}
	
	public void setMinTemptime(String temp)
	{
		this.minTemptime=temp;
	}
	
	public void addData(Temperature temp)
	{
		tempTimeMap.put(temp.getTemperature(),temp.getTimeOfDay());
	}
	
	public List getDayTemperatureList()
	{
		return Arrays.asList(tempTimeMap.keySet().toArray());
	}

}
