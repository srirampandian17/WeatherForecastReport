package com.weather.objects;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Temperature {
	
	private double temperature;

	private String timeOfDay;
	
	public Temperature(Long timeofDay,double temperature)
	{
		Calendar cal1 = Calendar.getInstance();
		cal1.setTimeInMillis(timeofDay);
		SimpleDateFormat sdf = new SimpleDateFormat("dd,hh:mm aaa");
		this.timeOfDay=sdf.format(cal1.getTime())+"";
		this.temperature=temperature;
	}

	public double getTemperature()
	{
		return temperature;
	}
	
	public String getTimeOfDay()
	{
		return timeOfDay;
	}
}
